# Dr. Priya Clinic Website

This folder is a deployable static website exported from Stitch.

Entry point:
- index.html

Pages:
- about.html
- services.html
- appointments.html
- patient-information.html
- contact.html

Online consultation:
- ₹200 consultation fee
- Payment can be made later
- WhatsApp CTA is included on the home page

IMPORTANT:
The WhatsApp number in the Stitch export is 919840012345. Replace it with Dr. Priya Clinic's real WhatsApp number before publishing if this is only a placeholder.

Deploy:
1. Upload this folder to Netlify Drop, or
2. Create a GitHub repository and upload all files, then import that repository into Vercel/Netlify.
